--
-- PostgreSQL database dump
--

-- Dumped from database version 14.17 (Homebrew)
-- Dumped by pg_dump version 14.17 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: jsonb_deep_merge(jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: charlie.kerr
--

CREATE FUNCTION public.jsonb_deep_merge(a jsonb, b jsonb) RETURNS jsonb
    LANGUAGE sql
    AS $$
    SELECT 
        CASE 
            WHEN a IS NULL THEN b
            WHEN b IS NULL THEN a
            WHEN jsonb_typeof(a) <> 'object' OR jsonb_typeof(b) <> 'object' THEN b
            ELSE (
                SELECT jsonb_object_agg(
                    k,
                    CASE
                        WHEN jsonb_typeof(a->k) = 'object' 
                             AND jsonb_typeof(b->k) = 'object'
                        THEN jsonb_deep_merge(a->k, b->k)
                        WHEN b ? k
                        THEN b->k
                        ELSE a->k
                    END
                )
                FROM (
                    SELECT DISTINCT k
                    FROM jsonb_object_keys(a || b) k
                )s
            )
        END
$$;


ALTER FUNCTION public.jsonb_deep_merge(a jsonb, b jsonb) OWNER TO "charlie.kerr";

--
-- Name: merge_people(integer, integer); Type: FUNCTION; Schema: public; Owner: charlie.kerr
--

CREATE FUNCTION public.merge_people(primary_id integer, secondary_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Update canonical_id for all records pointing to secondary_id
    UPDATE People 
    SET canonical_id = primary_id 
    WHERE canonical_id = secondary_id;
    
    -- Update the secondary record to point to primary
    UPDATE People 
    SET canonical_id = primary_id 
    WHERE id = secondary_id;
    
    -- Update relationships where secondary_id is source
    UPDATE Relationships 
    SET source_id = primary_id 
    WHERE source_id = secondary_id;
    
    -- Update relationships where secondary_id is target
    UPDATE Relationships 
    SET target_id = primary_id 
    WHERE target_id = secondary_id;
END;
$$;


ALTER FUNCTION public.merge_people(primary_id integer, secondary_id integer) OWNER TO "charlie.kerr";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: charlie.kerr
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name character varying NOT NULL,
    website character varying,
    description text,
    industry character varying[],
    size_range character varying,
    funding_stage character varying,
    total_funding numeric,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.companies OWNER TO "charlie.kerr";

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: charlie.kerr
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.companies_id_seq OWNER TO "charlie.kerr";

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: charlie.kerr
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: datasources; Type: TABLE; Schema: public; Owner: charlie.kerr
--

CREATE TABLE public.datasources (
    id integer NOT NULL,
    name character varying NOT NULL,
    type character varying NOT NULL,
    raw_data jsonb DEFAULT '{}'::jsonb,
    last_sync_at timestamp without time zone,
    sync_status character varying,
    error_log text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.datasources OWNER TO "charlie.kerr";

--
-- Name: datasources_id_seq; Type: SEQUENCE; Schema: public; Owner: charlie.kerr
--

CREATE SEQUENCE public.datasources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.datasources_id_seq OWNER TO "charlie.kerr";

--
-- Name: datasources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: charlie.kerr
--

ALTER SEQUENCE public.datasources_id_seq OWNED BY public.datasources.id;


--
-- Name: people; Type: TABLE; Schema: public; Owner: charlie.kerr
--

CREATE TABLE public.people (
    id integer NOT NULL,
    canonical_id integer,
    full_name character varying,
    role character varying,
    twitter_handle character varying,
    github_handle character varying,
    linkedin_url character varying,
    ethereum_wallet character varying,
    external_data jsonb DEFAULT '{"farcaster": {"wallet": null, "username": null}}'::jsonb,
    repos jsonb DEFAULT '[]'::jsonb,
    github_stats jsonb DEFAULT '{"commitsCount": 0, "additionsCount": 0, "deletionsCount": 0, "contributionsRank": null}'::jsonb,
    crypto_activity jsonb DEFAULT '{"interests": []}'::jsonb,
    recruiter_notes text DEFAULT ''::text,
    ai_insights jsonb DEFAULT '{"skills": [], "interests": []}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT check_handle_presence CHECK (((twitter_handle IS NOT NULL) OR (github_handle IS NOT NULL)))
);


ALTER TABLE public.people OWNER TO "charlie.kerr";

--
-- Name: people_crypto_interests; Type: VIEW; Schema: public; Owner: charlie.kerr
--

CREATE VIEW public.people_crypto_interests AS
 SELECT people.id,
    people.full_name,
    (people.crypto_activity -> 'interests'::text) AS crypto_interests
   FROM public.people;


ALTER TABLE public.people_crypto_interests OWNER TO "charlie.kerr";

--
-- Name: people_farcaster; Type: VIEW; Schema: public; Owner: charlie.kerr
--

CREATE VIEW public.people_farcaster AS
 SELECT people.id,
    people.full_name,
    people.twitter_handle,
    people.github_handle,
    ((people.external_data -> 'farcaster'::text) ->> 'username'::text) AS farcaster_username
   FROM public.people;


ALTER TABLE public.people_farcaster OWNER TO "charlie.kerr";

--
-- Name: people_id_seq; Type: SEQUENCE; Schema: public; Owner: charlie.kerr
--

CREATE SEQUENCE public.people_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.people_id_seq OWNER TO "charlie.kerr";

--
-- Name: people_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: charlie.kerr
--

ALTER SEQUENCE public.people_id_seq OWNED BY public.people.id;


--
-- Name: relationships; Type: TABLE; Schema: public; Owner: charlie.kerr
--

CREATE TABLE public.relationships (
    id integer NOT NULL,
    source_id integer NOT NULL,
    target_id integer NOT NULL,
    type character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    strength double precision,
    last_interaction timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.relationships OWNER TO "charlie.kerr";

--
-- Name: relationships_id_seq; Type: SEQUENCE; Schema: public; Owner: charlie.kerr
--

CREATE SEQUENCE public.relationships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.relationships_id_seq OWNER TO "charlie.kerr";

--
-- Name: relationships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: charlie.kerr
--

ALTER SEQUENCE public.relationships_id_seq OWNED BY public.relationships.id;


--
-- Name: vcs; Type: TABLE; Schema: public; Owner: charlie.kerr
--

CREATE TABLE public.vcs (
    id integer NOT NULL,
    name character varying NOT NULL,
    website character varying,
    focus_areas character varying[],
    investment_stages character varying[],
    typical_check_size character varying,
    total_aum numeric,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.vcs OWNER TO "charlie.kerr";

--
-- Name: vcs_id_seq; Type: SEQUENCE; Schema: public; Owner: charlie.kerr
--

CREATE SEQUENCE public.vcs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vcs_id_seq OWNER TO "charlie.kerr";

--
-- Name: vcs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: charlie.kerr
--

ALTER SEQUENCE public.vcs_id_seq OWNED BY public.vcs.id;


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: datasources id; Type: DEFAULT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.datasources ALTER COLUMN id SET DEFAULT nextval('public.datasources_id_seq'::regclass);


--
-- Name: people id; Type: DEFAULT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.people ALTER COLUMN id SET DEFAULT nextval('public.people_id_seq'::regclass);


--
-- Name: relationships id; Type: DEFAULT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.relationships ALTER COLUMN id SET DEFAULT nextval('public.relationships_id_seq'::regclass);


--
-- Name: vcs id; Type: DEFAULT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.vcs ALTER COLUMN id SET DEFAULT nextval('public.vcs_id_seq'::regclass);


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: charlie.kerr
--

COPY public.companies (id, name, website, description, industry, size_range, funding_stage, total_funding, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: datasources; Type: TABLE DATA; Schema: public; Owner: charlie.kerr
--

COPY public.datasources (id, name, type, raw_data, last_sync_at, sync_status, error_log, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: charlie.kerr
--

COPY public.people (id, canonical_id, full_name, role, twitter_handle, github_handle, linkedin_url, ethereum_wallet, external_data, repos, github_stats, crypto_activity, recruiter_notes, ai_insights, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: relationships; Type: TABLE DATA; Schema: public; Owner: charlie.kerr
--

COPY public.relationships (id, source_id, target_id, type, metadata, strength, last_interaction, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vcs; Type: TABLE DATA; Schema: public; Owner: charlie.kerr
--

COPY public.vcs (id, name, website, focus_areas, investment_stages, typical_check_size, total_aum, created_at, updated_at) FROM stdin;
\.


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: charlie.kerr
--

SELECT pg_catalog.setval('public.companies_id_seq', 1, false);


--
-- Name: datasources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: charlie.kerr
--

SELECT pg_catalog.setval('public.datasources_id_seq', 1, false);


--
-- Name: people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: charlie.kerr
--

SELECT pg_catalog.setval('public.people_id_seq', 1, false);


--
-- Name: relationships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: charlie.kerr
--

SELECT pg_catalog.setval('public.relationships_id_seq', 1, false);


--
-- Name: vcs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: charlie.kerr
--

SELECT pg_catalog.setval('public.vcs_id_seq', 1, false);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: datasources datasources_pkey; Type: CONSTRAINT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.datasources
    ADD CONSTRAINT datasources_pkey PRIMARY KEY (id);


--
-- Name: people people_github_handle_key; Type: CONSTRAINT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT people_github_handle_key UNIQUE (github_handle);


--
-- Name: people people_pkey; Type: CONSTRAINT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- Name: people people_twitter_handle_key; Type: CONSTRAINT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT people_twitter_handle_key UNIQUE (twitter_handle);


--
-- Name: relationships relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.relationships
    ADD CONSTRAINT relationships_pkey PRIMARY KEY (id);


--
-- Name: relationships unique_relationship; Type: CONSTRAINT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.relationships
    ADD CONSTRAINT unique_relationship UNIQUE (source_id, target_id, type);


--
-- Name: vcs vcs_pkey; Type: CONSTRAINT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.vcs
    ADD CONSTRAINT vcs_pkey PRIMARY KEY (id);


--
-- Name: idx_datasources_raw_data; Type: INDEX; Schema: public; Owner: charlie.kerr
--

CREATE INDEX idx_datasources_raw_data ON public.datasources USING gin (raw_data);


--
-- Name: idx_datasources_type; Type: INDEX; Schema: public; Owner: charlie.kerr
--

CREATE INDEX idx_datasources_type ON public.datasources USING btree (type);


--
-- Name: idx_people_ai_insights; Type: INDEX; Schema: public; Owner: charlie.kerr
--

CREATE INDEX idx_people_ai_insights ON public.people USING gin (ai_insights);


--
-- Name: idx_people_crypto_activity; Type: INDEX; Schema: public; Owner: charlie.kerr
--

CREATE INDEX idx_people_crypto_activity ON public.people USING gin (crypto_activity);


--
-- Name: idx_people_ethereum_wallet; Type: INDEX; Schema: public; Owner: charlie.kerr
--

CREATE INDEX idx_people_ethereum_wallet ON public.people USING btree (ethereum_wallet);


--
-- Name: idx_people_external_data; Type: INDEX; Schema: public; Owner: charlie.kerr
--

CREATE INDEX idx_people_external_data ON public.people USING gin (external_data);


--
-- Name: idx_people_github_handle; Type: INDEX; Schema: public; Owner: charlie.kerr
--

CREATE INDEX idx_people_github_handle ON public.people USING btree (github_handle);


--
-- Name: idx_people_github_stats; Type: INDEX; Schema: public; Owner: charlie.kerr
--

CREATE INDEX idx_people_github_stats ON public.people USING gin (github_stats);


--
-- Name: idx_people_repos; Type: INDEX; Schema: public; Owner: charlie.kerr
--

CREATE INDEX idx_people_repos ON public.people USING gin (repos);


--
-- Name: idx_people_twitter_handle; Type: INDEX; Schema: public; Owner: charlie.kerr
--

CREATE INDEX idx_people_twitter_handle ON public.people USING btree (twitter_handle);


--
-- Name: people people_canonical_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: charlie.kerr
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT people_canonical_id_fkey FOREIGN KEY (canonical_id) REFERENCES public.people(id);


--
-- PostgreSQL database dump complete
--

