--
-- PostgreSQL database dump
--

-- Dumped from database version 14.17 (Homebrew)
-- Dumped by pg_dump version 14.17 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Companies" (
    id integer NOT NULL,
    name character varying(255),
    website character varying(255),
    description text,
    company_details jsonb,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Companies" OWNER TO postgres;

--
-- Name: Companies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Companies_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Companies_id_seq" OWNER TO postgres;

--
-- Name: Companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Companies_id_seq" OWNED BY public."Companies".id;


--
-- Name: DataSources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DataSources" (
    id integer NOT NULL,
    name character varying(255),
    type character varying(255),
    source_details jsonb,
    last_sync timestamp with time zone,
    sync_status character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."DataSources" OWNER TO postgres;

--
-- Name: DataSources_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."DataSources_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."DataSources_id_seq" OWNER TO postgres;

--
-- Name: DataSources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."DataSources_id_seq" OWNED BY public."DataSources".id;


--
-- Name: People; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."People" (
    id integer NOT NULL,
    full_name character varying(255),
    gh_name character varying(255),
    x_username character varying(255),
    role character varying(255),
    website character varying(255),
    location character varying(255),
    email character varying(255),
    user_details jsonb,
    external_data jsonb DEFAULT '{"farcaster": {"wallet": null, "username": null}}'::jsonb,
    crypto_activity jsonb DEFAULT '{"interests": []}'::jsonb,
    recruiter_notes text,
    ai_insights jsonb DEFAULT '{"skills": [], "interests": []}'::jsonb,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."People" OWNER TO postgres;

--
-- Name: People_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."People_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."People_id_seq" OWNER TO postgres;

--
-- Name: People_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."People_id_seq" OWNED BY public."People".id;


--
-- Name: Relationships; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Relationships" (
    id integer NOT NULL,
    source_type character varying(255),
    source_id integer,
    target_type character varying(255),
    target_id integer,
    relationship_type character varying(255),
    relationship_details jsonb,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Relationships" OWNER TO postgres;

--
-- Name: Relationships_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Relationships_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Relationships_id_seq" OWNER TO postgres;

--
-- Name: Relationships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Relationships_id_seq" OWNED BY public."Relationships".id;


--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


ALTER TABLE public."SequelizeMeta" OWNER TO postgres;

--
-- Name: VCS; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VCS" (
    id integer NOT NULL,
    name character varying(255),
    website character varying(255),
    description text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."VCS" OWNER TO postgres;

--
-- Name: VCS_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."VCS_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."VCS_id_seq" OWNER TO postgres;

--
-- Name: VCS_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."VCS_id_seq" OWNED BY public."VCS".id;


--
-- Name: VCs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VCs" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    industry character varying(255),
    pedigree character varying(255),
    portfolio jsonb,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."VCs" OWNER TO postgres;

--
-- Name: VCs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."VCs_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."VCs_id_seq" OWNER TO postgres;

--
-- Name: VCs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."VCs_id_seq" OWNED BY public."VCs".id;


--
-- Name: Companies id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Companies" ALTER COLUMN id SET DEFAULT nextval('public."Companies_id_seq"'::regclass);


--
-- Name: DataSources id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DataSources" ALTER COLUMN id SET DEFAULT nextval('public."DataSources_id_seq"'::regclass);


--
-- Name: People id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."People" ALTER COLUMN id SET DEFAULT nextval('public."People_id_seq"'::regclass);


--
-- Name: Relationships id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Relationships" ALTER COLUMN id SET DEFAULT nextval('public."Relationships_id_seq"'::regclass);


--
-- Name: VCS id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VCS" ALTER COLUMN id SET DEFAULT nextval('public."VCS_id_seq"'::regclass);


--
-- Name: VCs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VCs" ALTER COLUMN id SET DEFAULT nextval('public."VCs_id_seq"'::regclass);


--
-- Data for Name: Companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Companies" (id, name, website, description, company_details, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: DataSources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DataSources" (id, name, type, source_details, last_sync, sync_status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: People; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."People" (id, full_name, gh_name, x_username, role, website, location, email, user_details, external_data, crypto_activity, recruiter_notes, ai_insights, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Relationships; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Relationships" (id, source_type, source_id, target_type, target_id, relationship_type, relationship_details, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SequelizeMeta" (name) FROM stdin;
20250421154845-create-initial-tables.js
20250422000000-create-people.js
20250422000001-create-companies.js
20250422000002-create-vcs.js
20250422000004-create-datasources.js
20250422000005-create-relationships.js
\.


--
-- Data for Name: VCS; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VCS" (id, name, website, description, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: VCs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VCs" (id, name, industry, pedigree, portfolio, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: Companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Companies_id_seq"', 1, false);


--
-- Name: DataSources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."DataSources_id_seq"', 1, false);


--
-- Name: People_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."People_id_seq"', 1, false);


--
-- Name: Relationships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Relationships_id_seq"', 1, false);


--
-- Name: VCS_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."VCS_id_seq"', 1, false);


--
-- Name: VCs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."VCs_id_seq"', 1, false);


--
-- Name: Companies Companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "Companies_pkey" PRIMARY KEY (id);


--
-- Name: DataSources DataSources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DataSources"
    ADD CONSTRAINT "DataSources_pkey" PRIMARY KEY (id);


--
-- Name: People People_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."People"
    ADD CONSTRAINT "People_pkey" PRIMARY KEY (id);


--
-- Name: Relationships Relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Relationships"
    ADD CONSTRAINT "Relationships_pkey" PRIMARY KEY (id);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: VCS VCS_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VCS"
    ADD CONSTRAINT "VCS_pkey" PRIMARY KEY (id);


--
-- Name: VCs VCs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VCs"
    ADD CONSTRAINT "VCs_pkey" PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

